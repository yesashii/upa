vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|08 Aug 2005 23:20:14 -0000
vti_extenderversion:SR|4.0.2.8912
