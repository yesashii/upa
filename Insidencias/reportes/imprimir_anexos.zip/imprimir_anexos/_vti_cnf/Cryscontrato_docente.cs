vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|09 Aug 2005 14:20:03 -0000
vti_extenderversion:SR|4.0.2.8912
